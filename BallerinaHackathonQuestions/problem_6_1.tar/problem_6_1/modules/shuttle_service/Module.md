An implementation of the shuttle service.
[//]: # (above is the module summary)

# Module Overview
An implementation of the shuttle service.
