An in-memory hub for `ProjZone`.
[//]: # (above is the module summary)

# Module Overview
An in-memory hub for `ProjZone`.
